package main.java.day07HomeWork.controller;

import main.java.day07HomeWork.service.BoardServiceImpl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class BoardControllerMain {

    public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException {
        System.out.println("게시판 프로그램");
        displayMenu();
    }

    private static void displayMenu() throws SQLException, IOException, ClassNotFoundException {
        String menuId;
        BoardServiceImpl boardServiceImpl = new BoardServiceImpl();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            boardServiceImpl.getAllBoard();

            System.out.println("1.게시글 등록 ");
            System.out.println("2.게시글 수정");
            System.out.println("3.게시글 삭제");
            System.out.println("4.게시글 검색");
            System.out.println("5.프로그램 종료");
            System.out.print("매뉴선택: ");
            menuId = scanner.nextLine();
            if (menuId.equals("1")) {
                boardServiceImpl.insert();
            } else if (menuId.equals("2")) {
                boardServiceImpl.modifyBoard();
            } else if (menuId.equals("3")) {
                boardServiceImpl.deleteBoard();
            } else if (menuId.equals("4")) {
                boardServiceImpl.searchBoard();
            } else if (menuId.equals("5")) {
                System.out.println("프로그램종료");
                System.exit(0);
            }

        }
    }
}
