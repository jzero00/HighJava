package main.java.day07HomeWork.dao;

import main.java.day07HomeWork.DBConnection;


import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

public class BoardDao {
    Connection conn = DBConnection.getConnection();
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    Statement stmt = null;
    Scanner scanner = new Scanner(System.in);

    public BoardDao() throws SQLException, IOException, ClassNotFoundException {
    }

    public void insert() throws SQLException {

        System.out.println("작성자:");
        String writer = scanner.nextLine();
        System.out.println("제목:");
        String title = scanner.nextLine();
        System.out.println("내용:");
        String content = scanner.nextLine();
        String sql = "insert into jdbc_board values(board_seq.nextval,?,?,sysdate,?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, title);
        pstmt.setString(2, writer);
        pstmt.setString(3, content);
        pstmt.executeUpdate();
        closeResource(pstmt);
    }

    public void getAllBoard() throws SQLException {
        String sql = "select * from jdbc_board";
        stmt = conn.createStatement();
        String getTotCnt = "select COUNT(*)FROM jdbc_board";
        rs = stmt.executeQuery(getTotCnt);
        int count = 0;
        while (rs.next()) {
            count = rs.getInt(1);
        }
        if (count == 0) {
            System.out.println("게시판에 아직 데이터가 없음");
        } else {
            rs = stmt.executeQuery(sql);
            System.out.println("게시글번호\t작성자\t제목\t내용\t등록일");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + "\t" + rs.getString(3) + "\t" + rs.getString(2) +
                        "\t" + rs.getString(5) + "\t" + rs.getString(4));
            }
        }
        closeResource(rs, stmt);

    }

    public void modifyBoard() throws SQLException {
        System.out.println("게시글 번호 입력");
        int no = Integer.parseInt(scanner.nextLine());
        String sql = "update jdbc_board SET board_content=? where board_no=" + no;
        System.out.println("수정할 게시글 내용 입력:");
        String content = scanner.nextLine();
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, content);
        pstmt.executeUpdate();

    }

    public void deleteBoard() throws SQLException {
        System.out.println("게시글 번호 입력");
        int no = Integer.parseInt(scanner.nextLine());
        String sql = "delete from jdbc_board  where board_no=" + no;
        pstmt = conn.prepareStatement(sql);
        pstmt.executeUpdate();
        closeResource(rs, pstmt);
    }

    public void searchBoard() throws SQLException {
        System.out.println("검색기능입니다.");
        String sql = "SELECT *FROM jdbc_board  WHERE board_title like '%'||?||'%' OR board_content  like'%'||?||'%' OR board_writer like '%'||?||'%' ";
        pstmt = conn.prepareStatement(sql);
        System.out.println("검색어:작성자이름,내용,제목중 하나로 검색하시면 됩니다.");
        System.out.println("검색어 입력:");
        String searchKeyword = scanner.nextLine();
        pstmt.setString(1, searchKeyword);
        pstmt.setString(2, searchKeyword);
        pstmt.setString(3, searchKeyword);
        rs = pstmt.executeQuery();
        System.out.println("검색완료");
        System.out.println("게시글번호\t작성자\t제목\t내용\t등록일");
        while (rs.next()) {
            System.out.println(rs.getInt(1) + "\t" + rs.getString(3) + "\t" + rs.getString(2) +
                    "\t" + rs.getString(5) + "\t" + rs.getString(4));
        }
        closeResource(rs, pstmt);
    }

    private static void closeResource(ResultSet rs, Statement stmt) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void closeResource(ResultSet rs, PreparedStatement pstmt) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void closeResource(PreparedStatement pstmt) {
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
