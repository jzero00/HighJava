package main.java.day07HomeWork.service;

import java.sql.SQLException;

public interface BoardService {
    public void insert() throws SQLException;
    public void getAllBoard() throws SQLException;
    public void modifyBoard() throws SQLException;
    public void deleteBoard() throws SQLException;
    public void searchBoard() throws SQLException;
}
