package main.java.day07HomeWork.service;

import main.java.day07HomeWork.dao.BoardDao;

import java.io.IOException;
import java.sql.SQLException;

public class BoardServiceImpl implements BoardService {
    BoardDao boardDao=new BoardDao();

    public BoardServiceImpl() throws SQLException, IOException, ClassNotFoundException {
    }


    @Override
    public void insert() throws SQLException {
     boardDao.insert();
    }

    @Override
    public void getAllBoard() throws SQLException {
        boardDao.getAllBoard();
    }

    @Override
    public void modifyBoard() throws SQLException {
        boardDao.modifyBoard();

    }

    @Override
    public void deleteBoard() throws SQLException {
        boardDao.deleteBoard();

    }

    @Override
    public void searchBoard() throws SQLException {
        boardDao.searchBoard();
    }
}
