package main.java.day07HomeWork;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
    private static Connection conn=null;

    private DBConnection() {
    }

    public  static Connection getConnection() {
        if(conn==null){
            try {
                String resource="C:\\Users\\ruddn\\Documents\\inteliJWorkSpace\\ AdvancedJavaProgramming\\src\\main\\resources\\db.properties";
                Properties prop=new Properties();
                File file=new File(resource);
                FileInputStream fileInputStream= null;
                try {
                    fileInputStream = new FileInputStream(file);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                try {
                    prop.load(fileInputStream);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String user = prop.getProperty("username");
                String pw = prop.getProperty("password");
                String url = prop.getProperty("url");
                String driverName=prop.getProperty("driver");

                Class.forName(driverName);
                conn = DriverManager.getConnection(url, user, pw);

            } catch (ClassNotFoundException cnfe) {
                System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
            } catch (SQLException sqle) {
                System.out.println("DB 접속실패 : " + sqle.toString());
            } catch (Exception e) {
                System.out.println("Unkonwn error");
                e.printStackTrace();
            }
            return conn;
        }
        return null;

    }
}
