package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;

import kr.or.ddit.util.DBUtil2;

public class Exam07 {
	Scanner s = new Scanner(System.in);
	
	
	void checkmenu() {
		int menu;
		
		do {
			System.out.println("게시판 입니다. 번호를 입력해주세요");
			System.out.println("1.글 작성 2.글 삭제 3.글 수정 4.전체 목록 5.검색 0.종료");
			menu = s.nextInt();
			
			switch(menu) {
			case 1:
				write(); //글 작성
				break;
			case 2:
				delete();//글 삭제
				break;
			case 3:
				revise();// 글 수정
				break;
			case 4:
				displayAll();// 전체 목록
				break;
				
			case 5:
				search();
				break;
				
			case 0: //종료
				System.out.println("종료합니다.");
				return;
			}			
			
		}while(menu!=0);
	}

	private void search() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		
		System.out.println();
		System.out.println("검색하실 작성자 이름을 입력해주세요>> ");
		String writer = s.next();
		
		try {
			conn = DBUtil2.getConnection();
			
			String sql = "select * from jdbc_board where board_writer = '"+writer+"'";
			
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next() == false) {
				System.out.println(writer + "작성자의 게시글이 없습니다.");
				return;
			}
			System.out.println("제목\t작성자\t날짜\t\t내용");
			Exam07[] rss = new Exam07[10];
			
			while(rs.next()) {
				String title = rs.getString("board_title");
				String writer1 = rs.getString("board_writer");
				Date date = rs.getDate("board_date");
				String cont = rs.getString("board_content");
				
				System.out.println(title + "\t" + writer1 + "\t" + date + "\t" + cont);
				System.out.println("-------------------------------------------");
			}
			
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			if(rs!=null)try{ rs.close(); }catch(SQLException ee){}
			if(stmt!=null)try{ stmt.close(); }catch(SQLException ee){}
			if(pstmt!=null)try{ pstmt.close(); }catch(SQLException ee){}		
			if(conn!=null)try{ conn.close(); }catch(SQLException ee){}
		}
		
	}

	private void revise() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		System.out.println();
		System.out.println("수정하실 작성자 이름을 입력하세요 >>");
		String writer = s.next();
		
		try {
			conn = DBUtil2.getConnection();
			
			String sql = "select * from jdbc_board where board_writer = '"+writer+"'";
			
//			pstmt = conn.prepareStatement(sql);
//			pstmt.setString(1, writer);
//			rs = pstmt.executeQuery();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next() == false) {
				System.out.println(writer + "님은 수정할 게시글이 없습니다.");		
				return;
			}
			System.out.println("제목을 입력하세요 >> ");
			String title = s.next();
			System.out.println("내용을 입력하세요.");
			s.nextLine();
			String cont = s.nextLine();
			
			String sql1 = "update jdbc_board set board_title = '"+title+"', " + " board_content = '"+cont+"'" +" where board_writer = '"+writer+"'";
			
			pstmt = conn.prepareStatement(sql1);
			
			int cnt = pstmt.executeUpdate();
			if(cnt > 0) {
			System.out.println(writer + "님 게시글 수정 완료");
			}else {
				System.out.println("수정 실패");
			}
			
		}catch(SQLException e) {
			System.out.println("예외발생");
			e.printStackTrace();
		}finally {
			if(rs!=null)try{ rs.close(); }catch(SQLException ee){}
			if(stmt!=null)try{ stmt.close(); }catch(SQLException ee){}
			if(pstmt!=null)try{ pstmt.close(); }catch(SQLException ee){}		
			if(conn!=null)try{ conn.close(); }catch(SQLException ee){}
		}
		
	}

	private void displayAll() {
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		System.out.println();
		System.out.println("-------------------------------------------------------");
		System.out.println("번호\t제목\t작성자\t날짜\t\t내용");
		
		try {
			conn = DBUtil2.getConnection();
			
			String sql = "select * from jdbc_board";
			
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			
			while(rs.next()) {
				int no = rs.getInt("board_no");
				String title = rs.getString("board_title");
				String writer = rs.getString("board_writer");
				Date date = rs.getDate("board_date");
				String cont = rs.getString("board_content");
				
				System.out.println(no + "\t" + title + "\t" + writer + "\t" + date + "\t" + cont );
				System.out.println("-------------------------------------------------------");
			}
			
			System.out.println("작업완료~");
			
		}catch(SQLException e) {
			System.out.println("예외발생");
			e.printStackTrace();
		}finally {
			if(rs!=null)try{ rs.close(); }catch(SQLException ee){}
			if(stmt!=null)try{ stmt.close(); }catch(SQLException ee){}
			if(pstmt!=null)try{ pstmt.close(); }catch(SQLException ee){}		
			if(conn!=null)try{ conn.close(); }catch(SQLException ee){}
		}
		
		
	}

	private void delete() {
		System.out.println();
		System.out.println("삭제하실 작성자 이름을 입력해주세요 >> ");
		String writer = s.next();
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		
		try {
			
			
			conn = DBUtil2.getConnection();
			
			String sql = "select * from jdbc_board where board_writer = '"+writer +"'";
//			String sql = "select count(*) from jdbc_board where board_writer = '?'";
			

			
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next() == false) {
				System.out.println(writer + "님의 게시글이 존재하지 않습니다.");
				return;
			}
			
			String sql1 = "delete jdbc_board where board_writer = '"+writer+"'";
			
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql1);
			if(rs.next() == true) {
				System.out.println(writer + "님 게시글 삭제 완료");
			}else {
				System.out.println(writer + "님 게시글 삭제 실패@!!!@!@!@!@!@");
			}
			
		} catch (SQLException e) {
			System.out.println("ㅇㅇㅇㅇ");
			e.printStackTrace();
		}finally {
			if(rs!=null)try{ rs.close(); }catch(SQLException ee){}
			if(stmt!=null)try{ stmt.close(); }catch(SQLException ee){}
			if(pstmt!=null)try{ pstmt.close(); }catch(SQLException ee){}			
			if(conn!=null)try{ conn.close(); }catch(SQLException ee){}
		}
		
		
		
	}

	private void write() {
		System.out.println();
		System.out.println("작성 페이지입니다.");
		System.out.print("제목을 입력해주세요. >> ");
		String title = s.next();
		System.out.println("작성자 이름을 입력해주세요. >>");
		String writer = s.next();
		System.out.println("내용을 입력해주세요");
		s.nextLine(); // 버퍼 비우기
		String content = s.nextLine();
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		
		try {
			
			
			conn = DBUtil2.getConnection();
			
			String sql = "insert into jdbc_board values(board_seq.nextval, ?, ?, sysdate, ?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, writer);			
			pstmt.setString(3, content);
			
			int cnt = pstmt.executeUpdate();
			
			if(cnt > 0) {
				System.out.println(writer + "님 작성 완료");
			}else {
				System.out.println("작성 실패!");
			}
			
			
			
			
			
		} 
			
		
		 catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		new Exam07().checkmenu();
	}
}


















