package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.PreparedStatement;
import kr.or.ddit.util.DBUtil2;

/*
 * 위의 테이블을 작성하고 게시판을 관리하는
다음 기능들을 구현하시오.

기능 구현하기 ==> 전체 목록 출력, 새글작성, 수정, 삭제, 검색 
 
------------------------------------------------------------

게시판 테이블 구조 및 시퀀스

create table jdbc_board(
    board_no number not null,  -- 번호(자동증가)
    board_title varchar2(100) not null, -- 제목
    board_writer varchar2(50) not null, -- 작성자
    board_date date not null,   -- 작성날짜
    board_content clob,     -- 내용
    constraint pk_jdbc_board primary key (board_no)
);
create sequence board_seq
    start with 1   -- 시작번호
    increment by 1; -- 증가값
		
----------------------------------------------------------

// 시퀀스의 다음 값 구하기
//  시퀀스이름.nextVal

 */
public class jdbc_board {
	Scanner scan = new Scanner(System.in);
	

	
	public void displayManu() {
		System.out.println("-----------------------------------");
		System.out.println("	1. 새 글 작성");
		System.out.println("	2. 글 수정");
		System.out.println("	3. 글 삭제");
		System.out.println("	4. 검색");
		System.out.println("	5. 전체 목록");
		System.out.println("	6. 작업 종료");
		System.out.println("-----------------------------------");
		System.out.println("작업을 선택하여 주세요.");
	}
	
	public void start() {
		int choice;
		do {
			displayManu();
			choice = scan.nextInt();
			switch (choice) {
			case 1: 
				board_writer();
				
				break;
			case 2:
				updateBoard();
				break;
			case 3:
				deleteBoard();
				break;
			case 4:
				boardAll(); //검색
				break;
			case 5:
				dispalyBoardAll(); //전체 목
				break;
			case 6:
				System.out.println("실행 종료");
			default:
				System.out.println("잘못 입력 하셨습니다. 확인하시고 다시 입력해 주세요.");
				break;
			}
		}while (choice != 6);
	}

	private void dispalyBoardAll() {
		
		System.out.println();
		System.out.println("-----------------------------------------------------");
		System.out.println("번호\t 제목\t 작성자\t 작성날짜\t 내용 ");
		System.out.println("-----------------------------------------------------");
		
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
		conn = DBUtil2.getConnection();
		
		String sql = "select * from jdbc_board";
		
		stmt = conn.createStatement();
		
		rs = stmt.executeQuery(sql);
		
		if(rs.next() == false) {
			System.out.println("입력하신 작성자의 게시글이 존재 하지 않습니다");
			return;
		}
		
		while(rs.next()) {
			String board_no = rs.getString("board_no");
			String board_title = rs.getString("board_title");
			String board_writer = rs.getString("board_writer");
			String board_date = rs.getString("board_date");
			String board_content = rs.getString("board_content");
			
			System.out.println(board_no + "\t"
							+ board_title + "\t"
							+ board_writer + "\t"
							+ board_date +"\t"
							+ board_content + "\t");
		}
		System.out.println("---------------------------------");
		System.out.println("출력 작업 끝");
		}catch(SQLException e) {
			System.out.println("작성 글 가져오기 실패");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}
	
	//검색
	private void boardAll() {
		System.out.println();
		System.out.println("찾고싶은 게시글의 제목을 입력하시오. ");
		String board_writer = scan.next();
		
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil2.getConnection();
			
			String sql = "select * from jdbc_board where board_writer";
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			if(rs.next() == false) {
				System.out.println("입력하신 작성자의 게시글이 존재 하지 않습니다");
			return;
			}
			
			while(rs.next()) {
				board_writer = rs.getString("board_writer");
				String board_no = rs.getString("board_no");
				String board_title = rs.getString("board_title");
				String board_date = rs.getString("board_date");
				String board_content = rs.getString("board_content");
				
				System.out.println(board_no + "\t"
								+ board_title + "\t"
								+ board_writer + "\t"
								+ board_date +"\t"
								+ board_content + "\t");	
			}
		}catch(SQLException e) {
			System.out.println("게시글 검색의 실패");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}
	private void deleteBoard() {
		System.out.println();
		System.out.println("삭제할 작성글의 작성자를 입력하시오.");
		String board_writer = scan.next();
		

		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil2.getConnection();
			String sql = "delete from jdbc_board where board_writer = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, board_writer);
			
			int cnt = pstmt.executeUpdate();
			if(cnt > 0) {
				System.out.println(board_writer + "삭제 성공");
			}else {
				System.out.println(board_writer + "삭제 실패");
			}
		}catch(SQLException e) {
			System.out.println(board_writer + "삭제 실패");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}
	//수정 하는 메서드
	private void updateBoard() {
		System.out.println();
		String board_writer = "";
		boolean check = true;
		

		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		

		do {
			System.out.println("수정 할 게시글의  작성자를 입력하세요");
			board_writer = scan.next();
				
			check = getWriter(board_writer);
				
			if(check == false) {
				System.out.println(board_writer + " 입력하신 작성자는 없는 정보입니다.");
				return;
				}
			}while(check == false);
			System.out.println("수정할 내용을 입력하세요");
			System.out.println("내용 입력");
			String board_content = scan.next();
			
		try {
			conn = DBUtil2.getConnection();
			String sql = "update jdbc_board set board_content = '?'";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, board_content);			
			
			int cnt = pstmt.executeUpdate();
			if(cnt > 0) {
				System.out.println(board_writer + "회원의 내용을 수정했습니다.");
			}else {
				System.out.println(board_writer + "내용 수정을 실패하셨습니다.");
			}
		}catch(SQLException e) {
			System.out.println(board_writer + "내용 수정을 실패 했습니다.");
		}finally {
			disConnect();
		}
	}
	//글을 작성 하는 메서드
	private void board_writer(){
		boolean check = false;
		String board_writer = "";
		do {
			System.out.println();
			System.out.print("작성자 >>");
			board_writer = scan.next();
			check = getWriter(board_writer);
			if(check) {
				System.out.println("작성자가 "+ board_writer + "존재 하지 않습니다");
			}
			
		}while(check == true);
		
		System.out.println();
		System.out.print("제목 >>");
		String jdbc_title = scan.next();
		
		scan.nextLine();
	
		System.out.println("내용 작성>");
		String board_content = scan.nextLine();
		
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
		conn = DBUtil2.getConnection();
		
		String sql = "insert into jdbc_board"
				+ " values(board_seq.nextval, ?, ?, sysdate,?)";
		
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, jdbc_title);
		pstmt.setString(2, board_writer);
		pstmt.setString(3, board_content);
		
		int cnt = pstmt.executeUpdate();
		
		if(cnt > 0) {
			System.out.println(board_writer + "님 작성에 성공 하셨습니다.");
		}else {
			System.out.println(board_writer + "님 작성에 실패 하셨습니다.");
		}
		}catch(SQLException e) {
			System.out.println(board_writer + "님 작성에 실패 하셨습니다.");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}

	private boolean getWriter(String board_writer) {
		return false;
	}


	private void disConnect() {
	

}
	public static void main(String[] args) {
		new jdbc_board().start();
	}
}