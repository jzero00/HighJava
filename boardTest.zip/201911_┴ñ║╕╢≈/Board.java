package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import kr.or.ddit.util.DBUtil2;

public class Board {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private Scanner scan = new Scanner(System.in);
	
	public void displayMenu() {
		System.out.println();
		System.out.println("========게시판=======");
		System.out.println("1. 새글작성");
		System.out.println("2. 수정");
		System.out.println("3. 삭제");
		System.out.println("4. 검색");
		System.out.println("5. 전체글목록");
		System.out.println("6. 게시판 종료");
		System.out.println("====================");
		System.out.print("메뉴를 선택해 주세요 >> ");
	}
	
	public void start() {
		int menu;
		do {
			displayMenu();
			menu = scan.nextInt();
			switch(menu) {
			case 1 : //새글작성
				insertBoard();
				break;
			case 2 : //수정
				updateBoard();
				break;
			case 3 : //삭제
				deleteBoard();
				break;
			case 4 : //검색
				searchBoard();
				break;
			case 5 : //전체목록출력
				displayBoardAll();
				break;
			case 6 : //종료
				System.out.println("게시판을 종료합니다.");
				break;
			default :
				System.out.println("번호를 잘못 입력했습니다.");
			}
		}while(menu != 6);
	}
	
	/**
	 * 전체 글목록 출력하는 메서드
	 */
	private void displayBoardAll() {
		System.out.println("---------------------------------------------");
		
		try {
			conn = DBUtil2.getConnection();
			
			String sql = "select * from jdbc_board";
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				int no = rs.getInt("board_no");
				String title = rs.getString("board_title");
				String writer = rs.getString("board_writer");
				String date = rs.getString("board_date");
				String content = rs.getString("board_content");
				
				System.out.println("글번호 : " + no);
				System.out.println("제목 : " + title);
				System.out.println("작성자 : " + writer);
				System.out.println("날짜 : " + date);
				System.out.println("내용 : " + content);
				System.out.println("---------------------------------------------");
			}
			System.out.println("출력 작업 끝...");
			
		}catch(SQLException e) {
			System.out.println("전체 글목록 가져오기 실패!!!");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}
	
	/**
	 * 작성자 이름으로 검색하는 메서드
	 */
	private void searchBoard() {
		System.out.println();
		System.out.println("검색할 작성자를 입력하세요 .");
		System.out.print("작성자 이름 >> ");
		String writer = scan.next();
		
		System.out.println("---------------------------------------------");
		
		try {
			conn = DBUtil2.getConnection();
			
			String sql = "select * from jdbc_board where board_writer = '" + writer + "'";
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				int no = rs.getInt("board_no");
				String title = rs.getString("board_title");
				writer = rs.getString("board_writer");
				String date = rs.getString("board_date");
				String content = rs.getString("board_content");
				
				System.out.println("글번호 : " + no);
				System.out.println("제목 : " + title);
				System.out.println("작성자 : " + writer);
				System.out.println("날짜 : " + date);
				System.out.println("내용 : " + content);
				System.out.println("---------------------------------------------");
			}
			System.out.println("출력 작업 끝...");
			
		}catch(SQLException e) {
			System.out.println("글목록 가져오기 실패!!!");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}

	/**
	 * 글 삭제하는 메서드
	 */
	private void deleteBoard() {
		System.out.println();
		System.out.println("삭제할 글 번호를 입력하세요.");
		System.out.print("번호 >> ");
		int boardNo = scan.nextInt();
		
		try {
			conn = DBUtil2.getConnection();
			String sql = "delete from jdbc_board where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNo);
			
			int cnt = pstmt.executeUpdate();
			if(cnt > 0) {
				System.out.println("글 삭제 성공...");
			}else {
				System.out.println("글 삭제 실패!!!");
			}
			
		}catch(SQLException e) {
			System.out.println("글 삭제 실패!!!");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}
	
	/**
	 * 글 수정하는 메서드
	 */
	private void updateBoard() {
		int boardNo;
		boolean check = true;
		
		do {
			System.out.println();
			System.out.println("수정할 글의 번호를 입력해주세요 >> ");
			System.out.print("글 번호 >> ");
			boardNo = scan.nextInt();
			
			check = getBoardSeq(boardNo);
			if(check == false) {
				System.out.println("등록된 글이 없습니다.");
				System.out.println("다시 입력하세요.");
			}
		}while(check == false);

		System.out.println("수정할 제목을 입력하세요.");
		System.out.print("새로운 제목 >> ");
		String title = scan.next();
		
		System.out.println("수정할 내용을 입력하세요.");
		scan.nextLine();
		System.out.println("새로운 내용 >> ");
		String content = scan.nextLine();
		
/*		//수정한 날짜로 저장
		String regDate;
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		Date time = new Date();
		regDate = format1.format(time);*/
		
		try {
			conn = DBUtil2.getConnection();
			
			String sql = "update jdbc_board set board_title = ?, board_content = ?, board_date = sysdate where board_no = " + boardNo;
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, content);
//			pstmt.setString(3, regDate);
			
			int cnt = pstmt.executeUpdate();
			
			if(cnt > 0) {
				System.out.println("글을 수정했습니다.");
			}else {
				System.out.println("글 수정 실패!!!");
			}
			
		}catch(SQLException e) {
			System.out.println("글 수정 실패!!!");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}

	/**
	 * 글 등록하는 메서드
	 */
	private void insertBoard() {
		
		System.out.print("작성자 이름을 입력해주세요 >> ");
		String writer = scan.next();
		
		System.out.print("제목을 입력해주세요 >> ");
		String title = scan.next();
		
		scan.nextLine();
		System.out.println("내용을 입력해주세요 >> ");
		String content = scan.nextLine();
		
/*		//날짜 - 현재날짜로 저장되게
		String regDate;
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		Date time = new Date();
		regDate = format1.format(time);*/
		
		try {
			conn = DBUtil2.getConnection();
			//글번호 자동 증가(시퀀스)
			String sql = "insert into jdbc_board (board_no, board_title, board_writer, board_date, board_content) values (board_seq.nextval,?,?,sysdate,?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, writer);
//			pstmt.setString(3, regDate);
			pstmt.setString(3, content);
			
			int cnt = pstmt.executeUpdate();
			
			if(cnt > 0) {
				System.out.println(writer + "님의 글이 등록됐습니다!");
			}else {
				System.out.println("글 등록에 실패했습니다!!!");
			}
			
		}catch(SQLException e) {
			System.out.println("글 작성에 실패했습니다!!!");
			e.printStackTrace();
		}finally {
			disConnect();
		}
	}
	
	/**
	 * 글번호를 이용하여 작성한 글이 있는지 확인하는 메서드
	 */
	private boolean getBoardSeq(int boardNo) {
		boolean check = false;
		try {
			conn = DBUtil2.getConnection();
			String sql = "select count(*) cnt from jdbc_board where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNo);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			
			if(cnt > 0) {
				check = true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			check = false;
		}finally {
			disConnect();
		}
		return check;
	}
	
	/**
	 * 자원 반납용 메서드
	 */
	private void disConnect() {
		if(rs!=null)try{ rs.close(); }catch(SQLException ee){}
		if(stmt!=null)try{ stmt.close(); }catch(SQLException ee){}
		if(pstmt!=null)try{ pstmt.close(); }catch(SQLException ee){}
		if(conn!=null)try{ conn.close(); }catch(SQLException ee){}
	}
	
	public static void main(String[] args) {
		Board boardObj = new Board();
		boardObj.start();
	}
	
}
		