package exam;


import java.sql.*;
import java.util.*;
import java.util.Date;

import kr.or.ddit.util.*;


public class CRUD {
	
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private Scanner scan = new Scanner(System.in); 
	
	/**
	 * 메뉴를 출력하는 메서드
	 */
	public void displayMenu(){
		System.out.println();
		System.out.println("------------------------------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 자료 입력");
		System.out.println("  2. 자료 삭제");
		System.out.println("  3. 자료 수정");
		System.out.println("  4. 전체 자료 출력");
		System.out.println("  5. 작업 끝.");
		System.out.println("------------------------------------------");
		System.out.print("원하는 작업 선택 >> ");
	}
	
	/**
	 * 프로그램 시작메서드
	 * @throws SQLException 
	 */
	public void start() throws SQLException{
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = scan.nextInt(); // 메뉴번호 입력받기
			switch(choice){
				case 1 :  // 자료 입력
					insertBoard();
					break;
				case 2 :  // 자료 삭제
					deleteBoard();
					break;
				case 3 :  // 자료 수정
					updateBoard();
					break;
				case 4 :  // 전체 자료 출력
					displayBoard();
					break;
				case 5 :  // 작업 끝
					System.out.println("작업을 마칩니다.");
					System.exit(0);
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=5);
	}
	
	
	
	/**
	 * 회원 정보를 삭제하는 메서드(입력받은 회원 ID를 이용하여 삭제한다.)
	 */
	private void deleteBoard() throws SQLException {
		System.out.println("\r\n삭제할 게시글 번호를 입력하세요. >> ");
		int no = scan.nextInt();		
		
			conn = DBUtil2.getConnection();
			String sql = "delete from jdbc_board where BOARD_NO = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			
			int cnt = pstmt.executeUpdate();
			if(cnt > 0) {
				System.out.println(no + "번 게시글 삭제성공");
			} else {
				System.out.println(no + "번 게시글 삭제실패");
			}
		
			disConnect();
		
		
	}

	/**
	 * 회원정보를 수정하는 메서드
	 */
	private void updateBoard() throws SQLException {
		System.out.println();
		int no = 0;
		boolean chk = true;
		
		do {
			System.out.println("수정할 게시판 번호 를 입력하세요 >> ");
			no = scan.nextInt();
			
			chk = getMember(no);
			
			if(chk == false) {
				System.out.println(no + "번 게시글은  없는 게시글입니다.");
				System.out.println("수정할 자료가 없으니 다시 입력하세요.");
			}
		}while(chk == false);
		
		System.out.println("수정할 내용을 입력하세요.");
		System.out.print("새로운 제목 >> ");
		String title = scan.next();
		
		System.out.print("새로운 작성자 >> ");
		String writer = scan.next();
		
		System.out.print("새로운 내용 >> ");
		String content = scan.next();
		
		
			conn = DBUtil2.getConnection();
			
			String sql = "update jdbc_board set board_title = ?, board_writer = ?, board_content = ? where BOARD_NO = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(4, no);
			pstmt.setString(1, title);
			pstmt.setString(2, writer);
			pstmt.setString(3, content);
			
			int cnt = pstmt.executeUpdate();
			
			if(cnt > 0) {
				System.out.println(no + "번 게시글의 정보를 수정했습니다.");
			}else {
			System.out.println(no + "번 게시글의 정보를 수정하지 못했습니다.");
			}
		
			disConnect();
		
	}	

	/**
	 * 모든 회원을 출력하는 메서드
	 */
	private void displayBoard() throws SQLException {
		System.out.println("\r\n------------------------------------------");
		System.out.println("번호\t제목\t작성자\t작성날짜\t"+"\t내용");
		
			conn = DBUtil2.getConnection();
			
			String sql = "select * from  jdbc_board";
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				int no = rs.getInt(1);
				String title = rs.getNString(2);
				String writer = rs.getNString(3);
				Date date = rs.getDate(4);
				String content = rs.getNString(5);
				
				System.out.println(no + "\t"+ title + "\t" + writer + "\t" + date +"\t" + content);
			}
			System.out.println("------------------------------------------\r\n");
		
			disConnect();
		
	}

	/**
	 * 회원추가하는 메서드
	 */
	private void insertBoard() throws SQLException {
		
		
		System.out.print("게시글 제목 >> ");
		String title = scan.next();
		
		System.out.println("작성자 >> ");
		String writer = scan.next();
		
		scan.nextLine(); //버퍼 비우기
		System.out.print("내용 >> ");
		String content = scan.nextLine();
		
		
			conn = DBUtil2.getConnection();
			String sql = "insert into jdbc_board values (board_seq.nextval, ?, ?,sysdate, ?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, writer);
			pstmt.setString(3, content);
			
			int cnt = pstmt.executeUpdate();
			
			if(cnt > 0) {
				System.out.println("게시글 등록 완료");
			} else {
				System.out.println("게시글 등록 실패");
			}
			disConnect();
		
		
	}

	/**
	 * 회원 ID를 이용하여 회원이 있는지 알려주는 메서드
	 * @param no
	 * @return true : 이미 존재하는 회원
	 * @return false : 신규회원
	 */
	private boolean getMember(int no) throws SQLException {
		
		boolean chk = false;
		
			conn = DBUtil2.getConnection();
			String sql = "select count(*) cnt from jdbc_board where BOARD_NO = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			if(cnt > 0) {
				chk = true;
			}
			disConnect();
		
		return chk;
	}

	/**
	 * 사용했던 자원 반납
	 */
	private void disConnect() throws SQLException {
		if(rs!=null) rs.close();
		if(stmt!=null) stmt.close(); 
		if(pstmt!=null) pstmt.close(); 
		if(conn!=null) conn.close(); 	
	}

	public static void main(String[] args) throws SQLException {
		CRUD crud = new CRUD();
		crud.start();
	}

}






