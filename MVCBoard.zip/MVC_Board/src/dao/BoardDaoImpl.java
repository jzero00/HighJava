package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import util.DBUtil;
import vo.BoardVO;

public class BoardDaoImpl implements BoardDao {

	private Connection conn;
	private Statement st;
	private PreparedStatement ps;
	private ResultSet rs;

	@Override
	public int regPost(BoardVO bv) {

		int cnt = 0;

		try {
			conn = DBUtil.getConnection();
			String sql = "INSERT INTO jdbc_board VALUES (BOARD_SEQ.NEXTVAL, ?, ?, SYSDATE, ?)";

			ps = conn.prepareStatement(sql);
			ps.setString(1, bv.getBoard_title());
			ps.setString(2, bv.getBoard_writer());
			ps.setString(3, bv.getBoard_content());

			cnt = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cnt;
	}



	@Override
	public int updatePost(BoardVO bv) {

		int cnt = 0;

		try {
			conn = DBUtil.getConnection();
			String sql = "UPDATE jdbc_board SET board_title = ?, board_content = ?, WHERE board_no = ?";

			ps = conn.prepareStatement(sql);
			ps.setString(1, bv.getBoard_title());
			ps.setString(2, bv.getBoard_content());
			ps.setInt(3, bv.getBoard_no());

			cnt = ps.executeUpdate();

			if (cnt > 0) {
				System.out.println("수정에 성공하셨습니다.");
			} else {
				System.out.println("수정에 실패하셨습니다.");
			}

			System.out.println("--------------------------------------------------------");
			System.out.println("출력작업 끝...");


		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cnt;
	}


	@Override
	public List<BoardVO> getAllPostList() {

		List<BoardVO> bdList = new ArrayList<BoardVO>();

		try {
			conn = DBUtil.getConnection();

			String sql = "select * from jdbc_board";

			st = conn.createStatement();

			rs = st.executeQuery(sql);

			while (rs.next()) {

				BoardVO bv = new BoardVO();

				bv.setBoard_no(rs.getInt("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));

				bdList.add(bv);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return bdList;
	}
	/**
	 * 자원반납용 메소드
	 */
	private void disconnect() {
		//사용했던 자원 반납
		if(rs!=null)try{ rs.close(); }catch(SQLException ee){}
		if(st!=null)try{ st.close(); }catch(SQLException ee){}
		if(ps!=null)try{ ps.close(); }catch(SQLException ee){}
		if(conn!=null)try{ conn.close(); }catch(SQLException ee){}
	}


	@Override
	public boolean getPost(int board_no) {
		
		boolean chk = false;

		try {
			conn = DBUtil.getConnection();
			String sql = "SELECT COUNT(*) AS cnt FROM jdbc_board WHERE board_no = ?";

			ps = conn.prepareStatement(sql);
			ps.setInt(1, board_no);

			rs = ps.executeQuery();

			int cnt = 0;
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}

			if(cnt > 0) {
				chk = true;
			} 	
		} catch (SQLException e) {
			e.printStackTrace();
			chk = false;
		} finally {
			disconnect();
		}
		return chk;
	}


	@Override
	public int deletePost(int board_no) {

		int cnt = 0;

		try {
			conn = DBUtil.getConnection();
			String sql = "DELETE FROM jdbc_board WHERE board_no = ?";

			ps = conn.prepareStatement(sql);
			ps.setInt(1, board_no);

			cnt = ps.executeUpdate();

		} catch (SQLException e) {
			System.out.println("삭제에 실패하셨습니다.");
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cnt;
	}
	



}
