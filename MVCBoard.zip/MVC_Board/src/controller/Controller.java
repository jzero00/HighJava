package controller;

import java.util.List;
import java.util.Scanner;

import service.BoardService;
import service.BoardServiceImpl;
import vo.BoardVO;

public class Controller {

	private BoardService bdService;

	public Controller() {
		bdService = new BoardServiceImpl();
	}

	private Scanner scan = new Scanner(System.in); 

	/**
	 * 메뉴를 출력하는 메서드
	 */
	public void displayMenu(){
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 글 작성");
		System.out.println("  2. 글 수정");
		System.out.println("  3. 글 삭제");
		System.out.println("  4. 전체 목록 출력");
		System.out.println("  5. 글 검색");
		System.out.println("  6. 작업 끝.");
		System.out.println("----------------------");
		System.out.print("원하는 작업 선택 >> ");
	}

	/**
	 * 프로그램 시작메서드
	 */
	public void start(){
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = Integer.parseInt(scan.nextLine()); // 메뉴번호 입력받기
			switch(choice){
			case 1 :  // 글 작성
				regPost();
				break;
			case 2 :  // 글 수정
				updateBoard();
				break;
			case 3 :  // 글 삭제
				deleteBoard();
				break;
			case 4 :  // 전체 목록 출력
				displayBoard();
				break;
			case 5 :  // 글 검색
				search();
				break;
			case 6 :  // 작업 끝
				System.out.println("작업을 마칩니다.");
				break;
			default :
				System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=6);
	}

	private void search() {
		
		System.out.println();
		System.out.println("검색할 정보를 입력하세요.");
		System.out.println("검색할 글의 제목을 입력해주세요.");
		String title = scan.nextLine().trim();
		
		System.out.println("검색할 글의 작성자를 입력해주세요.");
		String writer = scan.nextLine().trim();
		
		BoardVO bv = new BoardVO();
		bv.setBoard_content(bv.getBoard_content());
		bv.setBoard_date(bv.getBoard_date());
		bv.setBoard_no(bv.getBoard_no());
		bv.setBoard_writer(writer);
		bv.setBoard_title(title);
		
		List<BoardVO> boardList = bdService.searchPost(bv);
		
		if(boardList.size() == 0) {
			System.out.println("출력할 게시글 정보가 없습니다.");
		} else {
			for(BoardVO bv2 : boardList) {
				System.out.println(bv2.getBoard_no() + "\t" + bv.getBoard_writer() + "\t" + bv.getBoard_title() + "\t" + bv.getBoard_date() + "\t" + bv.getBoard_content());
			}
		}
	}

	private void displayBoard() {
		
		System.out.println();
		System.out.println("--------------------------------------------------------");
		System.out.println("번호\t제목\t\t작성자\t작성날짜\t\t\t\t내용");
		System.out.println("--------------------------------------------------------");
		
		List<BoardVO> boardList = bdService.getAllPostList();
		if(boardList.size() == 0){
			System.out.println("출력할 회원 정보가 없습니다.");
		} else {
			for(BoardVO bv : boardList) {
				System.out.println(bv.getBoard_no() + "\t" + bv.getBoard_title() + "\t" 
			+ bv.getBoard_writer() + "\t" + bv.getBoard_date() + "\t" + bv.getBoard_content());
			}
		}
		System.out.println("--------------------------------------------");
		System.out.println("출력작업 끝");
	}

	private void deleteBoard() {

		boolean check = true;
		int BoardNo;
		System.out.println();

		do {
			System.out.println("삭제할 글의 제목의 번호를 입력해주세요.");
			BoardNo = Integer.parseInt(scan.nextLine());
			
			check = getBoardNo(BoardNo);
			
			if (check == false) {
				System.out.println("삭제할 글이 존재하지 않습니다.");
				return;
			}
		} while (check == false);
		
		int cnt = bdService.deletePost(BoardNo);
		
		if(cnt > 0) {
			System.out.println(BoardNo + "번째 글 삭제 성공...");
		} else {
			System.out.println(BoardNo + "번째 글 삭제 실패!!!");
		}
		
	}

	private void updateBoard() {
		
		boolean check = true;
		int BoardNo;
		String title;
		String cont;
		System.out.println();
		
		
		do {
			System.out.println("수정할 글의 번호를 선택해주세요.");
			BoardNo = Integer.parseInt(scan.nextLine());
			
			check = getBoardNo(BoardNo);
			
			if (check == false) {
				System.out.println("수정할 글이 존재하지 않습니다.");
				return;
			}
		} while (check == false);
		
		System.out.println("수정할 내용을 입력하세요.");
		System.out.print("수정할 제목 이름 >> ");
		title = scan.next();
		
		System.out.println("수정할 내용 >> ");
		cont = scan.next();
		
		scan.nextLine();	//버퍼 비우기

		
		//입력받은 정보를 VO객체에 넣는다.
		BoardVO bv = new BoardVO();
		bv.setBoard_title(title);
		bv.setBoard_content(cont);
		
		int cnt = bdService.updatePost(bv);
		
		if(cnt > 0) {
			System.out.println(BoardNo + "번째 글 수정 완료...");
		} else {
			System.out.println(BoardNo + "번째 글 수정 실패...");
		}
	
		
	}
	/**
	 * 게시글 번호를 이용하여 게시글이 있는지 알려주는 메소드
	 * @param boardNo
	 * @return true : 이미 존재함, false : 신규회원
	 */
	private boolean getBoardNo(int boardNo) {

		boolean chk = false;
		
		chk = bdService.getPost(boardNo);
		
		return chk;
	}

	private void regPost() {

		String title;
		String writer;
		String cont;

		System.out.println();
		System.out.println("글작성을 시작합니다.");

		System.out.print("제목 : ");
		title = scan.nextLine().trim();
		System.out.print("작성자 : ");
		writer = scan.nextLine().replace(" ", "");
		System.out.print("내용 : ");
		cont = scan.nextLine().trim();

		// 입력받은 정보를 VO객체에 넣는다.
		BoardVO bv = new BoardVO();
		bv.setBoard_writer(writer);
		bv.setBoard_title(title);
		bv.setBoard_content(cont);

		int cnt = bdService.regPost(bv);
		
		if(cnt > 0) {
			System.out.println("글 등록 성공");
		} else {
			System.out.println("글 등록 실패");
		}


	}
	
	public static void main(String[] args) {
		Controller c = new Controller();
		c.start();
	}
}
